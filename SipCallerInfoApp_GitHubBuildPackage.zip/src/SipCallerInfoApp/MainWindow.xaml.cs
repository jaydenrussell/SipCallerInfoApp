using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;

namespace SipCallerInfoApp
{
    public sealed partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}
